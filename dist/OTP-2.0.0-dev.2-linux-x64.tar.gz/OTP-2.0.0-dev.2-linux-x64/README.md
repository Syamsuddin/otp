# ODIN Turbo Pascal v2.0

Implementasi mandiri dalam Rust dengan acuan Borland Turbo Pascal 7.0 DOS, identitas ODIN, dan lisensi GPL-3.0-only. Versi teknis paket ini **2.0.0-dev.2**. Ini merupakan milestone implementasi yang bisa dibangun dan diuji, **belum clone TP7 100% dan belum rilis produksi**.

Compiler sudah menghasilkan executable native untuk subset Pascal yang tercantum pada [matriks kompatibilitas](docs/COMPATIBILITY.md). Editor desktop, compiler CLI, runtime, logo, contoh, pengujian, skrip pemasangan, dan workflow build tersedia di source ini. Tidak memakai Free Pascal atau mengubah Pascal menjadi program Rust untuk dikompilasi dengan rustc.

## Mulai dari paket Linux yang disertakan

Paket binary yang benar-benar dibangun dalam pengerjaan ini ada di `dist/OTP-2.0.0-dev.2-linux-x64.tar.gz`. Dibangun pada Ubuntu 24.04 x86_64; mesin dengan glibc lebih lama belum diverifikasi. Desktop membutuhkan X11/XWayland. Compiler membutuhkan `cc` dan native C development libraries, biasanya dari paket `build-essential`. Python 3 dipakai oleh installer.

```sh
tar -xzf dist/OTP-2.0.0-dev.2-linux-x64.tar.gz
cd OTP-2.0.0-dev.2-linux-x64
sh install-linux.sh
~/.local/bin/otpc doctor
~/.local/bin/otp
```

Pemasangan dilakukan di akun pengguna, tanpa `sudo`. Lokasi dapat diganti dengan `OTP_PREFIX`. Binary juga bisa dijalankan langsung dari folder hasil ekstraksi:

```sh
./otpc run examples/FAKTORIAL.PAS
./otp examples/BELAJAR.PAS
```

Executable Pascal hasil build dapat dijalankan langsung; tidak memerlukan proses `otpc` atau IDE. Runtime Rust ditautkan secara statis ke executable tersebut. Library OS masih mengikuti platform host. Compiler di milestone ini belum mandiri dari assembler/linker sistem.

## Membangun source pada tiap OS

Pasang Rust **1.85.1**. Versi tercantum dalam `rust-toolchain.toml`. Source dependensi pihak ketiga tersedia dalam `vendor/`; konfigurasi Cargo memakai dependensi tersebut secara offline. Rust toolchain, SDK OS, dan linker bukan bagian dari arsip source.

| Host yang dituju | Prasyarat | Status binary dalam penyerahan ini |
|---|---|---|
| Linux x86_64 | Rust, C compiler/linker, Python 3; X11 untuk desktop | Dibangun dan executable Pascal diuji |
| Windows x86_64 | Rust MSVC, Visual Studio C++ Build Tools/Windows SDK, LLVM clang di PATH, Python 3; gunakan x64 Native Tools shell | Source, installer PowerShell, workflow tersedia; belum dibangun/diuji di Windows |
| macOS Intel | Rust, Xcode Command Line Tools, Python 3 | Source, skrip `.app`/DMG, workflow tersedia; belum dibangun/diuji di macOS |
| macOS Apple Silicon | Rust ARM64, Xcode Command Line Tools, Python 3 | Backend ARM64 dan jalur paket tersedia; belum dibangun/diuji di macOS |

Dari direktori project:

```sh
cargo build --workspace --release --locked --offline
cargo test --workspace --locked --offline
python3 tests/native_suite.py --release
python3 scripts/package.py --skip-build
```

Pada Windows gunakan `python` untuk menggantikan `python3`. `scripts/package.py` hanya mengemas hasil build pada host aktif. Tanpa `--skip-build`, skrip juga menjalankan build dan tes. CI di `.github/workflows/native.yml` menjalankan empat host secara terpisah dan menyimpan artefak ketika tes lulus; workflow belum dijalankan dalam sesi ini.

Hasil paket macOS yang dibangun pada Mac berisi `.app` dan DMG. Target minimum yang direncanakan macOS 11; belum diverifikasi pada perangkat. Untuk deployment target saat build: `MACOSX_DEPLOYMENT_TARGET=11.0 cargo build --workspace --release`. Signature yang dibuat skrip adalah ad-hoc untuk pengembangan; Developer ID/notarization masih merupakan gerbang rilis. Paket Windows berupa ZIP dan installer per pengguna, bukan MSI/EXE installer bertanda tangan.

## Compiler CLI

```sh
otpc check HELLO.PAS
otpc build HELLO.PAS -o hello
otpc run HELLO.PAS -- arg1 arg2
otpc build HELLO.PAS --range-check --overflow-check
otpc debug HELLO.PAS
otpc emit-asm HELLO.PAS --target macos-arm64 -o hello.s
otpc doctor
```

`build` dan `run` menghasilkan executable untuk OS/arsitektur host. `emit-asm` menyediakan assembly untuk `linux-x64`, `windows-x64`, `macos-x64`, dan `macos-arm64`; opsi itu belum menyediakan cross-linking atau executable platform lain dari satu host. File assembly disimpan dalam direktori `<output>.otp-build-<pid>`. `OTP_CC` memilih linker C alternatif, `OTP_RUNTIME` memilih arsip runtime yang sesuai host.

Debugger CLI menerima `s` (trace), `n` (step over), `c` (continue), `b NOMOR` (toggle breakpoint), dan `q` (stop). Debugger berkomunikasi dengan program native melalui socket loopback lokal. Hook disisipkan compiler sebelum statement. Snapshot scalar tersedia; debugger ini belum setara debugger TP7 secara lengkap.

## IDE

Jalankan `otp` atau `otp FILE.PAS`.

- F2 simpan, F3 pilih berkas/folder, F6 dan Shift+F6 pindah dokumen, F10 menu, Alt+X keluar.
- Menu Window: Tile, Cascade, F5 Zoom/Restore, Alt+F3 Close, dan List.
- Klik judul untuk mengaktifkan jendela. Seret judul untuk memindahkan, sudut kanan bawah untuk mengubah ukuran.
- Scrollbar vertikal/horizontal, roda mouse, serta Shift+roda mouse untuk geser horizontal.
- Dialog berkas: Tab memilih daftar/nama, Enter membuka folder/berkas, Ctrl+U naik folder, Ctrl+A mengganti filter.
- Penutupan dokumen berubah meminta SAVE/DISCARD. Save As meminta YES sebelum menimpa berkas. Esc membatalkan.
- Alt+F9 compile, Ctrl+F9 run/continue, Ctrl+F2 stop.
- F7 trace, F8 step over, Ctrl+F8 toggle breakpoint.
- Enter saat program berjalan membuka kotak input stdin; Ctrl+F5 memperbesar output.
- Ctrl+F cari, Ctrl+L berikutnya, menu Search untuk Replace all (`cari|pengganti`).
- Shift+panah memilih teks; Ctrl+C/X/V memakai clipboard internal OTP. Ctrl+Z/Y undo/redo.
- Help menampilkan batas implementasi; About menampilkan logo asli ODIN.

UI memakai framebuffer bitmap native. Pemilihan nama menu, warna biru/abu, dan tombol fungsi mengikuti pendekatan IDE DOS. Grid sekarang 100 × 35 sel; belum merupakan replika pixel dan event yang identik dengan TP7. Panel output merupakan transkrip, belum terminal DOS/CRT penuh. Jendela yang ditutup lewat window manager menyimpan perubahan belum tersimpan ke subfolder `odin-turbo-pascal-recovery` dalam direktori temporary OS; path dicetak ke stderr. Alt+X meminta ketikan `DISCARD` bila masih ada perubahan.

Panduan lengkap perbaikan jendela: [WINDOWS-dev2.md](docs/WINDOWS-dev2.md).

## Struktur

- `crates/otp-core`: lexer, parser, pemeriksaan semantik, generator assembly, driver linker.
- `crates/otp-types`: deskripsi tipe dan penyimpanan Real48.
- `crates/otp-rtl`: runtime Rust untuk tipe, operasi, I/O, CRT parsial, dan hook debugger.
- `crates/otp-cli`: executable `otpc`.
- `crates/otp-ide`: executable desktop `otp`, editor dan debugger frontend.
- `examples`: enam program Pascal untuk belajar dan memeriksa perilaku.
- `tests/native_suite.py`: pengujian black-box terhadap executable hasil kompilasi.
- `packaging`, `scripts`, `.github/workflows`: pemasangan dan build platform.
- `assets/branding`: master logo asli ODIN.
- `docs/RENCANA.md`: rencana v0.2 sebelumnya, dipertahankan sebagai acuan target penuh.
- `docs/IMPLEMENTASI.md`: bukti pengerjaan ini dan pekerjaan lanjutan.

## Lisensi dan asal kode

Source OTP dan runtime: GPL-3.0-only, lihat `LICENSE`. Tidak ada pengecualian linking runtime dalam milestone ini. Library infrastruktur menggunakan lisensi asal masing-masing, lihat `THIRD_PARTY.md`, `third-party-licenses/`, dan `vendor/`. Implementasi tidak menyertakan executable, source, font, help database, atau manual berhak cipta Borland. Tautan bahan pembanding dicatat dalam rencana; belum ada klaim lulus differential test terhadap executable TP7 asli.
