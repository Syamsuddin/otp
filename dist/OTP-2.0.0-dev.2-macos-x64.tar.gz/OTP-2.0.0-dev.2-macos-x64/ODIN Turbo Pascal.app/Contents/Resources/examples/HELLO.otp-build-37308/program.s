.text
.p2align 4
.globl _main
_main:
pushq %rbp
movq %rsp, %rbp
subq $48, %rsp
movabsq $0, %rdi
movabsq $0, %rsi
call _otp_init
movabsq $0, %rdi
movabsq $0, %rsi
call _otp_enter
leaq L_otp_3(%rip), %rdi
movabsq $40, %rsi
call _otp_string
movabsq $0, %rdi
call _otp_int
movabsq $-1, %rdi
call _otp_int
call _otp_write
movabsq $1, %rdi
call _otp_write_end
leaq L_otp_5(%rip), %rdi
movabsq $40, %rsi
call _otp_string
movabsq $0, %rdi
call _otp_int
movabsq $-1, %rdi
call _otp_int
call _otp_write
movabsq $1, %rdi
call _otp_write_end
L_otp_1:
movabsq $-1, %rdi
call _otp_leave
call _otp_finish
xorl %eax, %eax
leave
ret
.section __TEXT,__const
L_otp_3:
.byte 83,101,108,97,109,97,116,32,100,97,116,97,110,103,32,100,105,32,79,68,73,78,32,84
.byte 117,114,98,111,32,80,97,115,99,97,108,32,118,50,46,48,0
L_otp_5:
.byte 67,111,109,112,105,108,101,114,32,100,97,110,32,114,117,110,116,105,109,101,32,100,105,116
.byte 117,108,105,115,32,100,97,108,97,109,32,82,117,115,116,46,0
